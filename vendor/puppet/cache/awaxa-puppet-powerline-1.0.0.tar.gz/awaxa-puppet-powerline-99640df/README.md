# Powerline Fonts Puppet Module for Boxen

[![Build Status](https://travis-ci.org/awaxa/puppet-powerline.svg?branch=master)](https://travis-ci.org/awaxa/puppet-powerline)

## Usage

```puppet
include powerline
```

## Required Puppet Modules

None.
