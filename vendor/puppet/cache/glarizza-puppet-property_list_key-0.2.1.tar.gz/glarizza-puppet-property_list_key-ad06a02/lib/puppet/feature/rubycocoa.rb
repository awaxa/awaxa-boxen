require 'puppet/util/feature'
Puppet.features.add(:rubycocoa, :libs => ['osx/cocoa'])
