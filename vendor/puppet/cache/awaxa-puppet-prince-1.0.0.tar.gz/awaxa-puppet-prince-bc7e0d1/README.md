# Prince Puppet Module for Boxen

Installs [Prince](http://www.princexml.com) using homebrew.

[![Build Status](https://travis-ci.org/awaxa/puppet-prince.svg?branch=master)](https://travis-ci.org/awaxa/puppet-prince)

## Usage

```puppet
include prince
```
