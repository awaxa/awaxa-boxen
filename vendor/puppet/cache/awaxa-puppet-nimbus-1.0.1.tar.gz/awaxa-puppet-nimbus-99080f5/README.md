# Nimbus Puppet Module for Boxen

Installs [Nimbus](https://github.com/jnordberg/irccloudapp), the [IRCCloud](https://www.irccloud.com) app.

[![Build Status](https://travis-ci.org/awaxa/puppet-nimbus.svg?branch=master)](https://travis-ci.org/awaxa/puppet-nimbus)

## Usage

```puppet
include nimbus
```

## Required Puppet Modules

None.
